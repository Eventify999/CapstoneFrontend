import { CommonModule, DatePipe, NgClass } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

interface ApiResponse<T> {
  result: T[];
  isSuccess: boolean;
  message: string | null;
}

interface ServiceRequest {
  requestId: number;
  customerId: number;
  eventRequirementId: number;
  requestedAt: string;
  status: string;
}

interface Customer {
  customerId: number;
  customerName: string;
  phoneNumber: string;
  address: string;
}

interface EventDetails {
  eventRequirementId: number;
  customerId: number;
  eventType: string;
  location: string;
  eventDate: string;
  numberOfGuests: number;
  specialRequests: string;
  budget: number;
  description: string;
}

@Component({
  selector: 'app-vendorhome',
  standalone: true,
  imports: [CommonModule, FormsModule, NgClass, DatePipe],
  templateUrl: './vendorhome.component.html',
  styleUrls: ['./vendorhome.component.css']
})
export class VendorhomeComponent implements OnInit {
  allRequests: ServiceRequest[] = [];
  filteredRequests: ServiceRequest[] = [];
  selectedRequest: ServiceRequest | null = null;
  customerDetails: Customer | null = null;
  eventDetails: EventDetails | null = null;
  
  skeletonArray: number[] = Array(5).fill(0); // For loading skeletons
  isLoading = true;
  detailsLoading = false;
  searchTerm = '';
  statusFilter = 'all';
  sortBy = 'newest';
  activeTab = 'new';

  private readonly REQUESTS_API = 'https://localhost:5002/api/ServiceRequest';
  private readonly CUSTOMER_API = 'https://localhost:5002/api/Customer';
  private readonly EVENT_API = 'https://localhost:5002/api/Events';

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit(): void {
    this.fetchServiceRequests();
  }

  fetchServiceRequests(): void {
    this.isLoading = true;
    this.http.get<ApiResponse<ServiceRequest>>(this.REQUESTS_API)
      .subscribe({
        next: (response) => {
          this.allRequests = response.result || [];
          this.applyFilters();
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error fetching service requests:', error);
          this.isLoading = false;
        }
      });
  }

  applyFilters(): void {
    let requests = [...this.allRequests];
    
    // Filter based on active tab
    if (this.activeTab === 'new') {
      requests = requests.filter(req => req.status === 'Pending');
    } else if (this.activeTab === 'my') {
      requests = requests.filter(req => req.status !== 'Pending');
    }

    // Apply status filter for "My Requests" tab
    if (this.activeTab === 'my' && this.statusFilter !== 'all') {
      requests = requests.filter(req => req.status === this.statusFilter);
    }

    // Apply search filter
    if (this.searchTerm) {
      const term = this.searchTerm.toLowerCase();
      requests = requests.filter(request => 
        request.requestId.toString().includes(term) ||
        request.status.toLowerCase().includes(term) ||
        request.requestedAt.toLowerCase().includes(term)
      );
    }

    // Apply sorting
    this.filteredRequests = requests.sort((a, b) => {
      const dateA = new Date(a.requestedAt).getTime();
      const dateB = new Date(b.requestedAt).getTime();
      return this.sortBy === 'newest' ? dateB - dateA : dateA - dateB;
    });
  }

  viewRequestDetails(request: ServiceRequest): void {
    this.selectedRequest = request;
    this.detailsLoading = true;
    this.customerDetails = null;
    this.eventDetails = null;

    this.http.get<ApiResponse<Customer>>(`${this.CUSTOMER_API}?customerId=${request.customerId}`)
      .subscribe({
        next: (response) => {
          if (response.result && response.result.length > 0) {
            this.customerDetails = response.result[0];
          }
          this.checkDetailsLoaded();
        },
        error: (error) => {
          console.error('Error fetching customer details:', error);
          this.checkDetailsLoaded();
        }
      });

    this.http.get<ApiResponse<EventDetails>>(`${this.EVENT_API}?eventRequirementId=${request.eventRequirementId}`)
      .subscribe({
        next: (response) => {
          this.eventDetails = response.result && response.result.length > 0 ? response.result[0] : null;
          this.checkDetailsLoaded();
        },
        error: (error) => {
          console.error('Error fetching event details:', error);
          this.checkDetailsLoaded();
        }
      });
  }

  checkDetailsLoaded(): void {
    if ((this.customerDetails !== null || this.selectedRequest?.customerId === 0) && 
        (this.eventDetails !== null || this.selectedRequest?.eventRequirementId === 0)) {
      this.detailsLoading = false;
    }
  }

  updateRequestStatus(request: ServiceRequest, status: string): void {
    const originalStatus = request.status;
    request.status = status;
    
    this.http.put(`${this.REQUESTS_API}/${request.requestId}`, { ...request, status })
      .subscribe({
        next: () => {
          this.fetchServiceRequests();
          if (status === 'Accepted') {
            this.router.navigate(['/vendor/myrequests']);
          }
        },
        error: (error) => {
          console.error('Error updating request status:', error);
          request.status = originalStatus;
        }
      });
  }

  onTabChange(tab: string): void {
    this.activeTab = tab;
    this.applyFilters();
  }

  onStatusFilterChange(): void {
    this.applyFilters();
  }

  onSortChange(): void {
    this.applyFilters();
  }
}